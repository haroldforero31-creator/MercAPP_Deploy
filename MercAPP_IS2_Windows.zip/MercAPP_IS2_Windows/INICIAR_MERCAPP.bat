@echo off
title MercAPP IS2 - Punto de Venta
cd /d "%~dp0"

echo ========================================================
echo        Iniciando MercAPP IS2 (Punto de Venta)
echo ========================================================
echo.

if exist "MercAPP.exe" (
    echo [INFO] Iniciando ejecutable MercAPP.exe...
    start "" "MercAPP.exe"
    exit /b
)

where python >nul 2>nul
if %ERRORLEVEL% equ 0 (
    echo [INFO] Iniciando con Python...
    python launcher.py
    exit /b
)

echo [ERROR] No se encontro MercAPP.exe ni Python instalado.
pause
